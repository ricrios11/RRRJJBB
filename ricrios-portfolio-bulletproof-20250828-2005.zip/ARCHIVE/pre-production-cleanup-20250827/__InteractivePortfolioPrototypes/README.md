
  # Interactive Portfolio Prototypes

  This is a code bundle for Interactive Portfolio Prototypes. The original project is available at https://www.figma.com/design/4iORUuw18dwBlAfYpPH1oG/Interactive-Portfolio-Prototypes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  