import { PortfolioShowcase } from './components/PortfolioShowcase';

export default function App() {
  return <PortfolioShowcase />;
}