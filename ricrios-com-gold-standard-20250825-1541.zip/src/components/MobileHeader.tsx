// Legacy component removed - functionality migrated to UnifiedHeader.tsx
// This file is kept as placeholder to prevent import errors during migration